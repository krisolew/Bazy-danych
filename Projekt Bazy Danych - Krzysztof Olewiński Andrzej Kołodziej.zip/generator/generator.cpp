#include<iostream>
#include<ctime>
#include<fstream>
#include<cstdlib>
#include<string>
#include<windows.h>
using namespace std;
const int N = 6000;
string intToStr(long long n)
{
     string tmp, ret;
     if(n < 0) {
      ret = "-";
      n = -n;
     }
     do {
      tmp += n % 10 + 48;
      n -= n % 10;
     }
     while(n /= 10);
     for(int i = tmp.size()-1; i >= 0; i--)
      ret += tmp[i];
     return ret;
}
main(){
	srand (time(NULL));
	ifstream iname ("imiona.txt");
	ifstream ilastname ("lastname.txt");
	ifstream icity ("city.txt");
	ifstream istreet ("street.txt");
	ifstream daty ("daty.txt");
	ifstream tematy ("tematy.txt");
	ifstream warsztaty ("warsztaty.txt");
//tablice losowych danych
	string * name =new string[293];
	string * lastname  =new string[14455];
	string * city  =new string[1764];
	string * street  =new string[679];
	string  mail[5] = {"@gmail.com","@wp.pl","@onet.pl","@tlen.pl","@all.com"};
	string  country [3] = {"Polska","Polska","Niemcy"};
	string tdaty [157][3];
	string * ttmaty = new string [35];
	string  twarsztaty [7];
//wczytanie do tablic
	for (int i=0;i<290;i++)
		iname>>name[i];
	for (int i=0;i<14450;i++)
		ilastname>>lastname[i];
	for (int i=0;i<1760;i++)
		icity>>city[i];
	for (int i=0;i<670;i++)
		getline(istreet,street[i]);	
	for (int i=0;i<7;i++)
		getline(warsztaty,twarsztaty[i]);
	for (int i=0;i<156;i++){
		daty>>tdaty[i][0];
		daty>>tdaty[i][1];
		daty>>tdaty[i][2];
	}
	for (int i=0;i<35;i++)
		getline(tematy,ttmaty[i]);
		//cout<<city[1763];
//zmienne rekord�w
int liczba_firm = (rand()%3000)+1500;
int liczba_participants = liczba_firm * 6;
int liczba_dni = 0;
int liczba_Workshops = (rand()%6+4)*157;
int liczba_rezerwacjiK = 157*(rand()%50+10);
int liczba_rezerwacjiW = liczba_Workshops*30;
//odwzorowania tablic
	string **Customers =new string * [N];
	for (int i=0;i<N;i++)
		Customers[i]=new string [6];
	long long **Firm = new long long *[N];
	for(int i=0;i<liczba_firm;i++)
		Firm [i] = new long long  [3];		
	string **Participants = new string *[50000];
	for (int i=0;i<liczba_participants;i++)
		Participants[i]= new string [5];
	string **Conferences = new string* [157]; 
	for (int i=0;i<157;i++)
		Conferences [i]= new string [6];
	string **Days = new string* [459];
	for (int i=0;i<459;i++)
		Days[i]=new string [4];
	string **Workshops = new string* [3000];
	for (int i=0;i<liczba_Workshops;i++)
		Workshops[i]= new string [6];
	string **DaysReservations =new string *[40000];
	for (int i=0;i<liczba_rezerwacjiK;i++)
		DaysReservations [i] = new string [6];
	string **WorkshopsReservations = new string * [35000];
	for (int i=0;i<liczba_rezerwacjiW;i++)
		WorkshopsReservations [i]= new string [5];
	
	string **Payments = new string*[liczba_rezerwacjiK+liczba_rezerwacjiW];
	for (int i=0;i<liczba_rezerwacjiK+liczba_rezerwacjiW;i++)
		Payments[i]= new string [3];
//..uzupe�nianie klient�w
long long ost_firm =0;
//generowanie klient�w i firm
long long NIP, phone, REGON;
long long tmp;
Sleep(900);
	for (int i=0;i<N;i++){
		if (i==4000)
			Sleep(500);
		cout<<i<<endl;
		if (rand()%9>5){
			//cout<<"in firm";
			Firm [ost_firm][0]=i; 
			NIP = 7*rand()%1000000000;
			while (NIP <1000000000)
				NIP *= 7;
			tmp=NIP;
			Firm [ost_firm][1]=tmp;
			REGON = 7*rand()%1000000000;
			while (REGON <1000000000000)
				REGON *= 7;
			tmp=REGON;
			Firm[ost_firm][2]=tmp;
			ost_firm++;
			Customers[i][0]= lastname[rand()%14450]+"sp. z.o.o";
		}
		else
			Customers[i][0]=lastname[rand()%14450]+" "+name[rand()%290];
		Customers[i][1]=country[rand()%3];
		Customers[i][2]=city[rand()%1760];
		Customers[i][3]=street[rand()%670];
		phone = 7*rand()%1000000000;
		while (phone <100000000)
			phone *= 7;
		Customers[i][4]=intToStr(phone);
		if(rand()%3<2)
			Customers[i][5]=Customers[i][0]+mail[rand()%5];
	}	
	//cout<<Firm[0][0]<<endl<<ost_firm;
	//zapis do pliku aktualnych post�p�w 
	ofstream zapis ("final_out.txt");
	string option1 = "INSERT INTO Customers (Name, Country,  City, Street, Phone, Email) VALUES ('";
	string option2 = "INSERT INTO Customers (Name, Country,  City, Street, Phone) VALUES ('";
	for (int i=0;i<N;i++){
		if (Customers[i][5].length()==0)
			zapis<<option2<<Customers[i][0]<<"','"<<Customers[i][1]<<"','"<<Customers[i][2]<<"','"<<Customers[i][3]<<"','"<<Customers[i][4]<<"')\n";
		else
			zapis<<option1<<Customers[i][0]<<"','"<<Customers[i][1]<<"','"<<Customers[i][2]<<"','"<<Customers[i][3]<<"','"<<Customers[i][4]<<"','"<<Customers[i][5]<<"')\n";	
	}
	option1="INSERT INTO Firms (CustomerID, NIP, REGON) VALUES (";
	for (int i=0;i<ost_firm;i++)
		zapis<<option1<<Firm[i][0]<<","<<Firm[i][1]<<","<<Firm[i][2]<<")\n";
//generowanie konferencji i dni
Sleep(400);
int start;
int stop;
int how=0;
int tstart;
int tstop;
long long ilosc_warsztatow=0;
	for (int i=0;i<157;i++){
		cout<<i<<endl;
		start =rand()%3;
		stop = rand()%3;
		while (stop<start)
			stop ++;
		Conferences[i][0]=ttmaty[rand()%35];
		Conferences[i][1]=tdaty[i][start];
		Conferences[i][2]=tdaty[i][stop];
		Conferences[i][3]="Polska";
		Conferences[i][4]=city[rand()%1764];
		Conferences[i][5]=street[rand()%679];	
		
		for (int j=start;j<=stop;j++){
			how++;//liczba dni?
			Days[how][0]=intToStr(i+1);
			Days[how][1]=tdaty[i][j];
			Days[how][2]=intToStr(rand()%2000);

			for (int k=0;k<5;k++){				
				if (rand()%2==1){
					ilosc_warsztatow++;
					tstart = rand()%20;
					tstop = rand()%20;
					while (tstop<=tstart)
						tstop++;
					Workshops[ilosc_warsztatow][0]=intToStr(how);
					Workshops[ilosc_warsztatow][1]=ttmaty[rand()%35]+twarsztaty[rand()%7];
					Workshops[ilosc_warsztatow][2]=intToStr(tstart)+":00";
					Workshops[ilosc_warsztatow][3]=intToStr(tstop)+":00";
					Workshops[ilosc_warsztatow][4]=intToStr(rand()%400);
					Workshops[ilosc_warsztatow][5]=intToStr(10+rand()%20);
				}
			}
		}
	}
	option1="INSERT INTO Conferences (ConferenceName, StartDate, EndDate, Country, City, Street) VALUES ('";
	for (int i=0;i<157;i++)
		zapis<<Conferences[i][0]<<"','"<<Conferences[i][1]<<"','"<<Conferences[i][2]<<"','"<<Conferences[i][3]<<"','"<<Conferences[i][4]<<"','"<<Conferences[i][5]<<"')\n";
	option1="INSERT INTO Days ( ConferenceID, Date, Price) VALUES (";
	for (int i=0;i<how;i++)
		zapis<<Days[i][0]<<",'"<<Days[i][1]<<"',"<<Days[i][2]<<","<<"200)\n";
	option1="INSERT INTO Workshops (DayID,WorkshopNam, StartTime, EndTime, Price,NumOfPlace) VALUES (";
	for (int i=0;i<ilosc_warsztatow;i++)
		zapis<<Workshops[i][0]<<",'"<<Workshops[i][1]<<"','"<<Workshops[i][2]<<":00','"<<Workshops[i][3]<<":00',"<<Workshops[i][4]<<","<<Workshops[i][5]<<")\n";
		
option1="INSERT INTO DaysReservations (CustomerID,DayID,ReservationDate,IsCanceled,NumOfNormalParticipants, NumOfStudents) VALUES(";
option2="INSERT INTO Participants (CustomerID, FirstName, LastName, StudentCardNr) VALUES (	";
Sleep(400);
int customer_id;
int toJ=0;
int toK=0;
int to_pay=0;
int total_participants =0;
int day_reservation=0;
	for (int i=1;i<how;i++){
		if (i%50==0)
			Sleep(500);
		cout<<i<<" "<<day_reservation<<" "<<total_participants<<endl;
		toJ=(rand()%40)+50;
		for(int j=0;j<toJ;j++){
			customer_id=rand()%N;
			DaysReservations[j][0]=intToStr(customer_id);
			DaysReservations[j][1]=intToStr(i);
			DaysReservations[j][2]=tdaty[i-1][0];
			DaysReservations[j][3]=intToStr(0);
			toK=rand()%4;
			DaysReservations[j][4]=intToStr(toK);
			zapis<<option1<<DaysReservations[j][0]<<","<<DaysReservations[j][1]<<","<<DaysReservations[j][2]<<",'"<<DaysReservations[j][3]<<"',"<<DaysReservations[j][4]<<")\n";
			for(int k=0;k<toK;k++){
				Participants[total_participants][0]=DaysReservations[j][0];
				Participants[total_participants][1]=day_reservation;
				Participants[total_participants][2]=name[rand()%290];
				Participants[total_participants][3]=lastname[rand()%14450];
				Participants[total_participants][4]="0";
				zapis<<option2<<Participants[total_participants][0]<<","<<Participants[total_participants][1]<<",'"<<Participants[total_participants][2]<<"','"<<Participants[total_participants][3]<<"',"<<Participants[total_participants][4]<<")\n";
				total_participants++;
			}
			toK=rand()%2;
			DaysReservations[j][5]=intToStr(toK);
			for(int k=0;k<toK;k++){
				Participants[total_participants][0]=DaysReservations[j][0];
				Participants[total_participants][1]=day_reservation;
				Participants[total_participants][2]=name[rand()%290];
				Participants[total_participants][3]=lastname[rand()%14450];
				Participants[total_participants][4]=intToStr(rand()%1000000);
				zapis<<option2<<Participants[total_participants][0]<<","<<Participants[total_participants][1]<<",'"<<Participants[total_participants][2]<<"','"<<Participants[total_participants][3]<<"',"<<Participants[total_participants][4]<<")\n";
				total_participants++;
			}
			
		day_reservation++;
		}
	}
	
}
